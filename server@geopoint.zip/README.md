# Project-Geo-Point

Geo-Point is a api based web map service. Here, we find the shortest path between your Source location and Destination location. This is highly optimized and accurate.

We use leaflet js, a popular framework of JavaScript for mapping and tracing. 

Interactive responsive UI 🙂

